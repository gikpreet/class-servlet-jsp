package book;

public class Book extends BookInList {
    private String description;
    private int rating;

    public static class BookBuilder {
        private long isbn;
        private String title;
        private String subTitle;
        private String author;
        private String image;
        private int unitPrice;
        private String description;
        private int rating;
    
        public BookBuilder(long isbn, String title) {
            this.isbn = isbn;
            this.title = title;
        }
    
        public BookBuilder subTitle(String subTitle) {
            this.subTitle = subTitle;
            return this;
        }
    
        public BookBuilder author(String author) {
            this.author = author;
            return this;
        }
    
        public BookBuilder image(String image) {
            this.image = image;
            return this;
        }
    
        public BookBuilder unitPrice(int unitPrice) {
            this.unitPrice = unitPrice;
            return this;
        }

        public BookBuilder description(String description) {
            this.description = description;
            return this;
        }

        public BookBuilder rating(int rating) {
            this.rating = rating;
            return this;
        }
    
        public Book build() {
            Book book = new Book();
            book.isbn = this.isbn;
            book.title = this.title;
            book.subTitle = this.subTitle;
            book.author = this.author;
            book.image = this.image;
            book.unitPrice = this.unitPrice;
            book.description = this.description;
            book.rating = this.rating;
            return book;
        }
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getRating() {
        return this.rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}
