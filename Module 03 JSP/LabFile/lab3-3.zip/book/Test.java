package book;

import java.util.List;

public class Test {
    public static void main(String[] args) {
        List<BookInList> list = BookFactory.getBookFactory().searchByTitle("총");

        for(BookInList book: list) {
            System.out.print(book.getIsbn() + ", " + book.getTitle());
        }
    }
}
