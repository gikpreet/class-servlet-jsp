package book;

import java.util.Hashtable;

public class UserRepository {
    public Hashtable<Integer, String[]> users;
    public static UserRepository userRepository;

    private UserRepository() {
        this.users = new Hashtable<>();
    }

    public static UserRepository getUserRepository() {
        if (userRepository == null) {
            userRepository = new UserRepository();
        }
        return userRepository;
    }
}
