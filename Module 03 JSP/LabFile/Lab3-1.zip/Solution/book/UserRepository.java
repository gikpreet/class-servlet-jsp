package book;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Hashtable;

public class UserRepository {
    public Hashtable<Integer, String[]> userData;
    public static UserRepository userRepository;

    private UserRepository() {
        this.readData();
    }

    public static UserRepository getUserRepository() {
        if (userRepository == null) {
            userRepository = new UserRepository();
        }
        return userRepository;
    }

    public Hashtable<Integer, String[]> getData() {
        return this.userData;
    }

    public void readData() {
        this.userData = new Hashtable<>();
        String line = "";

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(BookRepository.class.getResourceAsStream("user.csv"), "UTF-8"))) {
        //try (BufferedReader reader = new BufferedReader(new InputStreamReader(new java.io.FileInputStream("user.csv"), "UTF-8"))) {
            while((line = reader.readLine()) != null) {
                String[] data = line.split("\\|");
                this.userData.put(Integer.parseInt(data[0]), data);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
