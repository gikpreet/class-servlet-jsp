package book;

public class User {
    private int userNo;
    private String userID;
    private String password;
    private String userName;

    public User(int userNo, String userID, String password, String userName) {
        this.userNo = userNo;
        this.userID = userID;
        this.password = password;
        this.userName = userName;
    }

    public int getUserNo() {
        return this.userNo;
    }

    public String getUserID() {
        return this.userID;
    }

    public String getUserName() {
        return this.userName;
    }

    public String getPassword() {
        return this.password;
    }
}
