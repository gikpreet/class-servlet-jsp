package book;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Hashtable;

public class BookFactory {
    private List<BookInList> list;
    private Hashtable<Integer, String[]> allbooklist;
    private static BookFactory factory;

    private BookFactory() {
        this.allbooklist = BookRepository.getBookRepository().getData();
    }

    public List<BookInList> searchByTitle(String title) {
        this.list = new ArrayList<>();
        for (Map.Entry<Integer, String[]> item: this.allbooklist.entrySet()) {
            String[] data = item.getValue();
            if (data[1].contains(title)) {
                list.add(this.createBookInList(Integer.parseInt(data[0]), data[1], data[2], data[3], data[4], Integer.parseInt(data[5])));
            }
        }
        return list;
    }

    public static BookFactory getBookFactory() {
        if(factory == null) {
            factory = new BookFactory(); 
        }
        return factory;
    }

    public List<BookInList> getBest5Books() {
        this.list = new ArrayList<>();

        for(int i = 1; i <= 5; i++) {
            String[] data = this.allbooklist.get(i);
            list.add(this.createBookInList(Integer.parseInt(data[0]), data[1], data[2], data[3], data[4], Integer.parseInt(data[5])));
        }
        return list;
    }

    public Book getBookInfo(int isbn) {
        return createBook(isbn);
    }

    private Book createBook(int key) {
        String[] data = this.allbooklist.get(key);
        return new Book.BookBuilder(Integer.parseInt(data[0]), data[1]).subTitle(data[2]).author(data[3]).image(data[4]).unitPrice(Integer.parseInt(data[5])).description(data[6].replace("\\r\\n", "<br />")).rating(Integer.parseInt(data[7])).build();
    } 

    private BookInList createBookInList(long isbn, String title, String subTitle, String author, String image, int unitPrice) {
        return new BookInList.BookInListBuilder(isbn, title).subTitle(subTitle).author(author).image(image).unitPrice(unitPrice).build();
    }
}
