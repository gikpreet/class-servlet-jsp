package book;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Hashtable;

public class UserFactory {
    List<User> userList;
    private static UserFactory userFactory;

    private UserFactory() {
        userList = new ArrayList<>();
        this.getUsers();
    }

    public boolean login(String userName, String password) {
        for (User user: this.userList) {
            if (user.getUserID().equals(userName) && user.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    public User getUser(int userNo) {
        for (User user: this.userList) {
            if (user.getUserNo() == userNo) {
                return user;
            }
        }
        return null;
    }

    public User getUser(String userID) {
        for (User user: this.userList) {
            if (user.getUserID().equals(userID)) {
                return user;
            }
        }
        return null;
    }

    private void getUsers() {
        Hashtable<Integer, String[]> userData = UserRepository.getUserRepository().getData();
        for (Map.Entry<Integer, String[]> item: userData.entrySet()) {
            this.userList.add(new User(Integer.parseInt(item.getValue()[0]), item.getValue()[1], item.getValue()[2], item.getValue()[3]));
        }
    }
    
    public static UserFactory getUserFactory() {
        if (userFactory == null) {
            userFactory = new UserFactory();
        }
        return userFactory;
    }
}
