package book;

public class BookInList {
    protected long isbn;
    protected String title;
    protected String subTitle;
    protected String author;
    protected String image;
    protected int unitPrice;

    public static class BookInListBuilder {
        private long isbn;
        private String title;
        private String subTitle;
        private String author;
        private String image;
        private int unitPrice;
    
        public BookInListBuilder(long isbn, String title) {
            this.isbn = isbn;
            this.title = title;
        }
    
        public BookInListBuilder subTitle(String subTitle) {
            this.subTitle = subTitle;
            return this;
        }
    
        public BookInListBuilder author(String author) {
            this.author = author;
            return this;
        }
    
        public BookInListBuilder image(String image) {
            this.image = image;
            return this;
        }
    
        public BookInListBuilder unitPrice(int unitPrice) {
            this.unitPrice = unitPrice;
            return this;
        }
    
        public BookInList build() {
            BookInList bookInList = new BookInList();
            bookInList.isbn = this.isbn;
            bookInList.title = this.title;
            bookInList.subTitle = this.subTitle;
            bookInList.author = this.author;
            bookInList.image = this.image;
            bookInList.unitPrice = this.unitPrice;
            return bookInList;
        }
    }

    public long getIsbn() {
        return this.isbn;
    }

    public String getTitle() {
        return this.title;
    }

    public String getSubTitle() {
        return this.subTitle;
    }

    public String getAuthor() {
        return this.author;
    }

    public String getImage() {
        return this.image;
    }

    public int getUnitPrice() {
        return this.unitPrice;
    }
}