package book;

import java.util.List;
import java.util.ArrayList;

public class BookFactory {
    public static List<BookInList> getBest5Books() {
        List<BookInList> list = new ArrayList<>();
        list.add(createBookInList(1, "이노베이터", "창의적인 삶으로 나아간 천재들의 비밀", "월터 아이작슨", "innovator.jpg", 42000));
        list.add(createBookInList(2, "모비 딕", "", "허먼 멜빌", "mobydick.jpg", 50000));
        list.add(createBookInList(3, "코스모스", "특별판", "칼 세이건", "cosmos.jpg", 50000));
        list.add(createBookInList(4, "총, 균, 쇠", "인간사회의 운명을 바꾼 힘", "제럴드 다이어몬드", "ggs.jpg", 26820));
        list.add(createBookInList(5, "세계대전 Z", "", "맥 스브록스", "worldwarz.jpg", 13800));

        return list;
    }

    public static BookInList createBookInList(long isbn, String title, String subTitle, String author, String image, int unitPrice) {
        return new BookInList.BookInListBuilder(isbn, title).subTitle(subTitle).author(author).image(image).unitPrice(unitPrice).build();
    }
}
