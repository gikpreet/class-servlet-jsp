package book;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Hashtable;

public class BookRepository {
    private Hashtable<Integer, String[]> bookData;
    private static BookRepository repository;

    private BookRepository() {
        readData();
    }

    public static BookRepository getBookRepository() {
        if (repository == null) {
            repository = new BookRepository();
        }
        return repository;
    }

    public Hashtable<Integer, String[]> getData() {
        return this.bookData;
    }

    public void readData() {
        this.bookData = new Hashtable<>();
        String line = "";

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(BookRepository.class.getResourceAsStream("book.csv"), "UTF-8"))) {
            while((line = reader.readLine()) != null) {
                String[] data = line.split("\\|");
                this.bookData.put(Integer.parseInt(data[0]), data);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
